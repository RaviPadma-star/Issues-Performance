dbcc tracestatus


DBCC TRACEON (1222, -1)
DBCC TRACEoff (1222, -1)

dbcc tracestatus

begin tran

update  [dbo].[Policies]
set PolicyFlag=1

update  [dbo].[Keys]
set InstallationID='00000000-0000-0000-0000-000000000000'
WAITFOR DELAY '00:00:05.000';