using System;
using System.Web;
using System.Security.Principal;
using System.Threading;
using System.Net.Mail;
using System.Data.SqlClient;
using System.Data;
using System.Globalization;
using System.Management;
using System.IO;
using System.Diagnostics;
using System.Net;


public class BlockedProcesses
{

    public static int Main(string[] args)
    {


        //*************************** START OF CONFIGURE ITEMS BY DBA*********************************


        string ApplicationName = "Test";

        string ServerName = "Exxxxxxxxx";

        string Email_To = @"rajasekharreddyb.dba@gmail.com";

     string SMS_To = @"+919966246368@sms.gmail.com";

        string connectionstring = @"Integrated Security=SSPI;Persist Security Info=False;Initial Catalog=Monitoring;Data Source=Exxxxxxxxx";

 
        //*************************** END OF CONFIGURE ITEMS BY DBA*********************************


        String TotalBody = String.Empty;
        String MainBody = String.Empty;
        String Query = String.Empty;

        String BlocksDetails = String.Empty;
        String BlocksHeader = String.Empty;

        string DbServers = Dns.GetHostName();
        string SMSText = ApplicationName + " : " + ServerName;

        int Disk_Threshold = 10;

        int Blocks_flag = 0;
        int Space_flag = 0;

        try
        {
            //---------------------------------------------------------Writing the connection ------------------------------------------------

            SqlConnection conn = new SqlConnection(connectionstring);

	        //--------------------- BLOCKS INFORMATION ------------------------------------------


            SqlCommand cmd = new SqlCommand();
            conn.Open();
            cmd.Connection = conn;
            Query = @"SELECT SP_ID,BLOCKED_BY,SQL_QUERY,STATUS,HOST_NAME,BLOCKED_FOR from Monitoring.dbo.BLOCKED_PROCESSES";
            SqlDataAdapter adapter = new SqlDataAdapter(Query, conn);
            DataSet ds = new DataSet();
            adapter.Fill(ds, "Blocked Processes");
            conn.Close();

            if (ds != null && ds.Tables != null && ds.Tables.Count > 0)
            {
                DataTable dt = ds.Tables[0];

                foreach (DataRow dr in dt.Rows)
                {
                    Blocks_flag = 1;
                    BlocksDetails += "<tr>";
                    BlocksDetails += "<td><font color=#666633>" + dr["SP_ID"].ToString() + " </font></td>";
                    BlocksDetails += "<td><font color=#666633>" + dr["BLOCKED_BY"].ToString() + " </font></td>";
                    BlocksDetails += "<td><font color=#666633>" + dr["SQL_QUERY"].ToString() + " </font></td>";
                    BlocksDetails += "<td><font color=#666633>" + dr["STATUS"].ToString() + " </font></td>";
                    BlocksDetails += "<td><font color=#666633>" + dr["HOST_NAME"].ToString() + " </font></td>";
                    BlocksDetails += "<td><font color=#666633>" + dr["BLOCKED_FOR"].ToString() + " </font></td>";
                }

                BlocksHeader = "<Table border=1 bgcolor=#CCFF99><tr><th colspan=33><h3><font color=#0066FF>Blocks Information</font></h3></th></tr>";
                BlocksHeader += "<tr><th><font color=#0066FF>SP_ID</font></th><th><font color=#0066FF>Blocked_By</font></th><th><font color=#0066FF>SQL_Query</font></th><th><font color=#0066FF>Status</font></th><th><font color=#0066FF>Host Name</font></th><th><font color=#0066FF>Blocked for(In Sec)</font></th></tr>";
                Console.WriteLine("Completed Reading Blocks information ");
            }


            //--------------------------------------------------------DISK SPACES -------------------------------------------------

/*
            int ServerNumber = 1;
            ConnectionOptions opt = new ConnectionOptions();

            ObjectQuery oQuery = new ObjectQuery("SELECT Size, FreeSpace, Name, FileSystem FROM Win32_LogicalDisk WHERE DriveType = 3");

            string sLine = DbServers;
            while (sLine != null)
            {
                if (ServerNumber <= 1)
                {
                    sLine = DbServers;
                }
                else
                {
                    sLine = null;
                }

                if (sLine != null)
                {
                    ManagementScope scope = new ManagementScope("\\\\" + sLine + "\\root\\cimv2", opt);

                    ManagementObjectSearcher moSearcher = new ManagementObjectSearcher(scope, oQuery);
                    ManagementObjectCollection collection = moSearcher.Get();
                   
                    foreach (ManagementObject res in collection)
                    {
                        decimal size = Convert.ToDecimal(res["Size"]) / 1024 / 1024 / 1024;
                        decimal freeSpace = Convert.ToDecimal(res["FreeSpace"]) / 1024 / 1024 / 1024;
                        
                        if ((Decimal.Round(freeSpace / size, 2) * 100) < Disk_Threshold)
                        {
                            Space_flag = 1;
                            SMSText += "\n"+res["Name"]+"\t"+Decimal.Round(size,2)+"\t"+Decimal.Round(freeSpace,2)+"\t"+Decimal.Round(freeSpace / size, 2) * 100 + "%";
                        }
                    }
                }
                ServerNumber += 1;

            }

            ServerNumber = 0;
            */

            //------------------------------------------------------ASSIGING ALL THE ITEMS TO THE MAIN TABLE-----------------------------------------

            MainBody = "<table border=0 bgcolor=#FFFFCC>";

            MainBody += "<tr valign=top><td colspan=2 valign=top width=100%>" + BlocksHeader + BlocksDetails + "</td></tr>";

            MainBody += "</table>";

            TotalBody = "<html><body>" + MainBody + "</body></html>"; 
        }
        catch (Exception ex)
        {
            TotalBody = "<html><body>" + ex.Message + "</body></html>";
        }

        //************************************************************** SENDING MAIL *************************************************************
        if (Blocks_flag > 0)
        {
            using (MailMessage mail = new MailMessage())
            {
                mail.To.Add(Email_To);
                mail.From = new MailAddress("Database Alerts <No-Reply@gmail.com>", @"Database Alerts");
                mail.IsBodyHtml = true;
                mail.Subject = ApplicationName + "  >>  " + ServerName + "  >>  Blocked Processes Alert " ;
                mail.Body = TotalBody;
                SmtpClient SmtpMail = new SmtpClient("smtp.gmail.com");
                Console.WriteLine("Mail Sent sucessfully with blocked processes information");
                SmtpMail.Send(mail);
            }
        }
        else
        {
            Console.WriteLine("No blocked processes at this point of time.");
        }
        if (Space_flag > 0)
        {
            using (MailMessage mail = new MailMessage())
            {
                mail.To.Add(SMS_To);
                mail.From = new MailAddress("Database Alerts <No-Reply@gmail.com>", @"Database Alerts");
                mail.IsBodyHtml = false;
                mail.Subject = "Disk Space Alert";
                mail.Body = SMSText;
                SmtpClient SmtpMail = new SmtpClient("smtp.gmail.com");
                Console.WriteLine("SMS Sent sucessfully with disk space information");
                SmtpMail.Send(mail);
            }
        }
        else
        {
            Console.WriteLine("As of now no issues with diskspace.");
        }
        
        return 0;
    }
}


