-- suggested indexes
SELECT 
'create nonclustered index ix_'+object_name(object_id, database_id)+' on '+
object_name(object_id)+
'('+
CASE WHEN equality_columns IS NOT NULL THEN equality_columns ELSE '' END +
CASE WHEN inequality_columns IS NOT NULL THEN +','+inequality_columns ELSE '' END+
') '+
CASE WHEN included_columns is not null THEN + ' INCLUDE ('+included_columns+')' ELSE '' END

,migs.group_handle, mid.*
,  round(avg_total_user_cost * avg_user_impact * (user_seeks + user_scans),0) as notional_benefit
, avg_total_user_cost
, avg_user_impact 
,user_seeks 
,user_scans
FROM sys.dm_db_missing_index_group_stats AS migs
INNER JOIN sys.dm_db_missing_index_groups AS mig
    ON (migs.group_handle = mig.index_group_handle)
INNER JOIN sys.dm_db_missing_index_details AS mid
    ON (mig.index_handle = mid.index_handle)
WHERE migs.group_handle in
(
-- pick out the 10 most beneficial missed indexes
SELECT TOP 50 group_handle
FROM sys.dm_db_missing_index_group_stats
ORDER BY avg_total_user_cost * avg_user_impact * (user_seeks + user_scans)DESC
)

order by avg_total_user_cost * avg_user_impact * (user_seeks + user_scans) desc