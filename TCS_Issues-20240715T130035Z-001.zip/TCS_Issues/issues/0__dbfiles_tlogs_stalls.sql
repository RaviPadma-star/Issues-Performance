if object_id('tempdb..#files') is not null
begin
  drop table #files
end

create table #files
(
dbname sysname default ''
,name sysname                                                                                                                            
,fileid int
,filename varchar(200)                                                                                                                                                                                                                                                        
,filegroup varchar(200)                                                                                                                        
,size    varchar(50)           
,maxsize varchar(50)          
,growth  varchar(50)           
,usage varchar(50)     
, spaceused_mb decimal(21,3) default -1
)


if object_id('tempdb..#r') is not null
begin
  drop table #r
end

if object_id('tempdb..#t') is not null
begin
  drop table #t
end

create table #r (dbname sysname, logfragmentcount bigint)
create table #t (a bigint,b bigint, c bigint, d bigint, e bigint, f bigint, g varchar(50))
exec sp_MSforeachdb "truncate table #t; use ?; insert #t  exec ('dbcc loginfo with no_infomsgs'); insert #r select '?', count(*) from #t"

--insert #files 
exec  sp_MSforeachdb 'use [?]; insert #files (name,fileid,filename,filegroup,size,maxsize,growth,usage) exec sp_helpfile; update #files set dbname =''?'', spaceused_mb = fileproperty( ''''+name+'''', ''SpaceUsed'') / 128.0
 where dbname ='''''

select 
           f.dbname,
           f.name as logical_file_name,
           f.fileid,
           f.filename,
           IsNull(f.filegroup, 'transaction log') as Filegroup,
           r.logfragmentcount,
           f.growth,
           convert( decimal(21,3), convert(decimal(21,3), replace(f.size, ' KB','')) / 1024.0) as size_mb,
           f.spaceused_mb,
           convert( decimal(21,3), convert(decimal(21,3), replace(f.size, ' KB','')) / 1024.0) - spaceused_mb as spacefree_mb,
           
		  convert( decimal(21,3),round(s.readstall_ms_per_io, 3))		as readstall_ms_per_io, 
		  convert( decimal(21,3),round(s.writestall_ms_per_io, 3))		as writestall_ms_per_io,
		  convert( decimal(21,3),round(s.stalls_per_io, 3))				as stalls_per_io,
		  convert( decimal(21,3),round(s.read2write_ratio_bytes, 3))	as read2write_ratio_bytes,
		  s.num_of_bytes_read,
		  s.num_of_bytes_written           
           
from #files f
left outer join #r r on
	f.dbname = r.dbname and f.fileid = 2
left outer join 	
(
SELECT 
  db_name(database_id) as dbname,
  database_id,
  file_id,
  CASE WHEN num_of_reads <> 0 THEN convert(decimal(21,3), io_stall_read_ms) / num_of_reads ELSE 0 END as readstall_ms_per_io, 
  CASE WHEN num_of_writes <> 0 THEN convert(decimal(21,3), io_stall_write_ms) / num_of_writes ELSE 0 END  as writestall_ms_per_io,
  CASE WHEN num_of_reads+num_of_writes <> 0 THEN convert(decimal(21,3), io_stall) / (num_of_reads + num_of_writes) ELSE 0 END  as stalls_per_io,
  CASE WHEN num_of_bytes_written <> 0 THEN convert(decimal(29,4), num_of_bytes_read) / num_of_bytes_written ELSE 999999 END as read2write_ratio_bytes
  ,num_of_bytes_read
  ,num_of_bytes_written
  FROM sys.dm_io_virtual_file_stats(NULL, NULL)
) as s on
  f.dbname = s.dbname and f.fileid = s.file_id

  