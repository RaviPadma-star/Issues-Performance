
-- =============================================
-- Declare and using a READ_ONLY cursor
-- =============================================




USE [Management]
GO

/****** Object:  Table [dbo].[xxx]    Script Date: 02/19/2010 15:09:50 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('tempdb..#ix') is not null
begin
	drop table #ix
end

CREATE TABLE [#ix](
	[DatabaseName] [nvarchar](128) NULL,
	[SchemaName] [nvarchar](128) NULL,
	[TableName] [nvarchar](128) NULL,
	[IndexName] [sysname] NULL,
	[object_id] [int] NULL,
	[index_id] [int] NULL,
	[partitionnum] [int] NULL,
	[frag] [float] NULL,
	[index_type_desc] [nvarchar](60) NULL,
	[alloc_unit_type_desc] [nvarchar](60) NULL,
	[Size_8kpages] [int] NULL,
	[Rows] [int] NULL,
	[OrigFillFactor] [tinyint] NULL,
	[DefragOperation] [varchar](10) NOT NULL
) ON [PRIMARY]

GO



SET NOCOUNT ON
DECLARE curDBID CURSOR
READ_ONLY
FOR select database_id from sys.databases

DECLARE @dbid int
DECLARE @db varchar(5000)
OPEN curDBID

FETCH NEXT FROM curDBID INTO @dbid
WHILE (@@fetch_status <> -1)
BEGIN
	IF (@@fetch_status <> -2)
	BEGIN

		SET @db = '['+db_name(@dbid)+']'
		
		select @db= 'USE ' +@db+';
		INSERT #ix
		SELECT
			 db_name(database_id) as DatabaseName,
			 OBJECT_SCHEMA_NAME(object_id, database_id) as SchemaName,
			 Object_Name(F.object_id) as TableName,
			 I.Name as IndexName,
			 F.object_id,
			 F.index_id,
			 F.partition_number AS partitionnum,
			 F.avg_fragmentation_in_percent AS frag,
			 F.index_type_desc,
			 F.alloc_unit_type_desc,
			 I.Reserved as Size_8kpages,
			 I.Rows,
			 I.OrigFillFactor,
			 CASE 
				WHEN F.avg_fragmentation_in_percent < 15 THEN ''NOTNEEDED''
				WHEN F.avg_fragmentation_in_percent < 30 THEN ''REORGANIZE''
				ELSE ''REBUILD''
			 END   as DefragOperation
		   FROM sys.dm_db_index_physical_stats (DB_ID(), NULL, NULL , NULL, ''LIMITED'') F
		   JOIN sys.sysindexes I ON
		   
			 F.Object_id = I.ID AND
			 F.Index_id = I.Indid
		   WHERE index_id > 0 and I.Reserved > 100 and F.avg_fragmentation_in_percent > 20
		   ORDER BY  F.avg_fragmentation_in_percent DESC'
	   
			
			exec(@db)
			
	END
	FETCH NEXT FROM curDBID INTO @dbid
END

CLOSE curDBID
DEALLOCATE curDBID
GO



Select * from #ix