select db_name(ius.database_id) as db_name, object_name(ius.object_id, ius.database_id) as table_name, si.name,  ius.* , si.is_unique, si.type_desc
from sys.dm_db_index_usage_stats ius
join sys.indexes si on
	ius.object_id = si.object_id and
	ius.index_id = si.index_id
where ius.user_seeks+ius.user_scans+ius.user_lookups= 0 and ius.user_updates > 1000
and si.is_unique = 0 
--and si.type_desc = 'CLUSTERED'
order by ius.user_updates desc


