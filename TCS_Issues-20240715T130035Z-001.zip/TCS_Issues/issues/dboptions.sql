USE TEMPDB
GO
CREATE TABLE #TMP
(
[DBName] nvarchar(128),
[Setting] nvarchar(128),
[Value] nvarchar(128)
)
--
CREATE TABLE #PARA
(
ID int identity(1,1),
[Para] nvarchar(128)
)


INSERT INTO #PARA(Para) VALUES ('database_id')
INSERT INTO #PARA(Para) VALUES ('source_database_id')
INSERT INTO #PARA(Para) VALUES ('owner_sid') 
INSERT INTO #PARA(Para) VALUES ('create_date')
INSERT INTO #PARA(Para) VALUES ('compatibility_level')
INSERT INTO #PARA(Para) VALUES ('collation_name')
INSERT INTO #PARA(Para) VALUES ('user_access')
INSERT INTO #PARA(Para) VALUES ('user_access_desc')
INSERT INTO #PARA(Para) VALUES ('is_read_only')
INSERT INTO #PARA(Para) VALUES ('is_auto_close_on')
INSERT INTO #PARA(Para) VALUES ('is_auto_shrink_on')
INSERT INTO #PARA(Para) VALUES ('state')
INSERT INTO #PARA(Para) VALUES ('state_desc')
INSERT INTO #PARA(Para) VALUES ('is_in_standby')
INSERT INTO #PARA(Para) VALUES ('is_cleanly_shutdown')
INSERT INTO #PARA(Para) VALUES ('is_supplemental_logging_enabled')
INSERT INTO #PARA(Para) VALUES ('snapshot_isolation_state')
 INSERT INTO #PARA(Para) VALUES ('snapshot_isolation_state_desc')
INSERT INTO #PARA(Para) VALUES ('is_read_committed_snapshot_on') 
INSERT INTO #PARA(Para) VALUES ('recovery_model')
 INSERT INTO #PARA(Para) VALUES ('recovery_model_desc')
INSERT INTO #PARA(Para) VALUES ('page_verify_option') 
INSERT INTO #PARA(Para) VALUES ('page_verify_option_desc')
INSERT INTO #PARA(Para) VALUES ('is_auto_create_stats_on')
 INSERT INTO #PARA(Para) VALUES ('is_auto_update_stats_on')
INSERT INTO #PARA(Para) VALUES ('is_auto_update_stats_async_on')
INSERT INTO #PARA(Para) VALUES ('is_ansi_null_default_on')
 INSERT INTO #PARA(Para) VALUES ('is_ansi_nulls_on') 
INSERT INTO #PARA(Para) VALUES ('is_ansi_padding_on') 
INSERT INTO #PARA(Para) VALUES ('is_ansi_warnings_on') 
INSERT INTO #PARA(Para) VALUES ('is_arithabort_on')
INSERT INTO #PARA(Para) VALUES ('is_concat_null_yields_null_on')
 INSERT INTO #PARA(Para) VALUES ('is_numeric_roundabort_on')
INSERT INTO #PARA(Para) VALUES ('is_quoted_identifier_on')
INSERT INTO #PARA(Para) VALUES ('is_recursive_triggers_on')
INSERT INTO #PARA(Para) VALUES ('is_cursor_close_on_commit_on')
INSERT INTO #PARA(Para) VALUES ('is_local_cursor_default')
 INSERT INTO #PARA(Para) VALUES ('is_fulltext_enabled')
 INSERT INTO #PARA(Para) VALUES ('is_trustworthy_on')
INSERT INTO #PARA(Para) VALUES ('is_db_chaining_on')
INSERT INTO #PARA(Para) VALUES ('is_parameterization_forced')
INSERT INTO #PARA(Para) VALUES ('is_master_key_encrypted_by_server')
INSERT INTO #PARA(Para) VALUES ('is_published') 
INSERT INTO #PARA(Para) VALUES ('is_subscribed')
INSERT INTO #PARA(Para) VALUES ('is_merge_published')
 INSERT INTO #PARA(Para) VALUES ('is_distributor') 
INSERT INTO #PARA(Para) VALUES ('is_sync_with_backup') 
INSERT INTO #PARA(Para) VALUES ('service_broker_guid')
INSERT INTO #PARA(Para) VALUES ('is_broker_enabled')
INSERT INTO #PARA(Para) VALUES ('log_reuse_wait')
INSERT INTO #PARA(Para) VALUES ('log_reuse_wait_desc')
INSERT INTO #PARA(Para) VALUES ('is_date_correlation_on')

/*
INSERT INTO #TMP(DBName) SELECT 
name
FROM sys.databases

DECLARE @str nvarchar(128)
DECLARE @db nvarchar(128)
DECLARE @Cmd nvarchar(2000)
DECLARE x CURSOR FOR SELECT Para from #para
OPEN x
FETCH NEXT FROM X INTO @str
WHILE @@FETCH_STATUS=0
	Begin
		DECLARE Z CURSOR FOR SELECT Name From sys.databases
		OPEN Z
		FETCH NEXT FROM Z INTO @db
		WHILE @@FETCH_STATUS=0
			Begin
				SET @Cmd='INSERT INTO #TMP(Dbname,Setting,[Value]) SELECT '+''''+@db+''''+','+''''+@str+''''+' ,'+@str+' FROM sys.databases  where name='+''''+@db+''''
				PRINT @CMD
				--EXEC (@CMD)
				FETCH NEXT FROM Z INTO @db				
			End
		CLOSE Z
		DEALLOCATE Z
		FETCH NEXT FROM X INTO @str
	END
CLOSE x
DEALLOCATE x
*/
--
DECLARE @str nvarchar(128)
DECLARE @db nvarchar(128)
DECLARE @Cmd nvarchar(2000)
DECLARE x CURSOR FOR SELECT Name From sys.databases
OPEN x
FETCH NEXT FROM x INTO @db
WHILE @@FETCH_STATUS=0
	Begin
		--DECLARE Z CURSOR FOR SELECT Name From sys.databases
		DECLARE z CURSOR FOR SELECT Para from #para
		OPEN Z
		FETCH NEXT FROM z INTO @str
		WHILE @@FETCH_STATUS=0
			Begin
				SET @Cmd='INSERT INTO #TMP(Dbname,Setting,[Value]) SELECT '+''''+@db+''''+','+''''+@str+''''+' ,'+@str+' FROM sys.databases  where name='+''''+@db+''''
				--PRINT @CMD
				EXEC (@CMD)
				FETCH NEXT FROM z INTO @str				
			End
		CLOSE Z
		DEALLOCATE Z
		--FETCH NEXT FROM X INTO @str
		FETCH NEXT FROM x INTO @db
	END
CLOSE x
DEALLOCATE x


Select * from #tmp